﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    // リジッドボディを使うための宣言
    Rigidbody2D rbody;

    // 変数宣言
    public float speed = 5f;              // 移動する速度
    public float jumpP = 1000f;           // ジャンプ力

    public float RayLength = 1f;          // rayの長さ

    public bool canHold;                  // オブジェクトを持てるかどうかをfireスクリプトに渡す

    private float time;                   // delay処理

    //string h_name = "name";               // rayにぶつかったオブジェクト名

    void Start()
    {
        // リジッドボディ2Dをコンポーネントから取得して変数に入れる
        rbody = GetComponent<Rigidbody2D>();

        canHold = false;

        time = 1.0f;
    }

    void Update()
    {
        Vector2 origin = this.transform.position; // 原点
        Vector2 direction = new Vector2(1, 0); // X軸方向を表すベクトル
        origin.x = origin.x + 1.5f;
        Ray2D ray = new Ray2D(origin, direction); // Rayを生成

        time += Time.deltaTime;


        // ジャンプ
        if (time >= 1.0f) // 1秒以内の連打をスルー
        {
            // キーボード
            // もしスペースキーが押されて、上方向に速度がない時に
            if (Input.GetKeyDown(KeyCode.Space) && rbody.velocity.y == 0)
            {
                // リジッドボディに力を加える（上方向にジャンプ力をかける）
                rbody.AddForce(transform.up * jumpP);

                time = 0.0f; // 時間を初期化
            }

            // コントローラー
            if (Input.GetButtonDown("Button_A") && rbody.velocity.y == 0)
            {
                // リジッドボディに力を加える（上方向にジャンプ力をかける）
                rbody.AddForce(transform.up * jumpP);

                time = 0.0f; // 時間を初期化
            }
        }

        // 移動(キーボード)
        if (Input.GetKey(KeyCode.A)) rbody.velocity = new Vector2(-speed, rbody.velocity.y);
        if (Input.GetKey(KeyCode.D)) rbody.velocity = new Vector2(speed, rbody.velocity.y);
        

        // 移動(コントローラー)
        const float SPEED = 0.1f;

        float x = Input.GetAxis("Horizontal_L_Stick");
        float y = Input.GetAxis("Vertical_L_Stick");

        this.gameObject.transform.position += new Vector3(x * SPEED, 0, y * SPEED);

        // ?????
        //if (Input.GetButtonDown("Horizontal Stick-L")) gameObject.transform.position += Vector3.up * SPEED;


        // rayを表示
        Debug.DrawRay(ray.origin, ray.direction * 3, Color.red);

        // rayとオブジェクトの当たり判定
        RaycastHit2D hit = Physics2D.Raycast((Vector2)ray.origin, (Vector2)ray.direction);
        // h_name = hit.collider.name; // 衝突した相手オブジェクトの名前を取得
        //Debug.Log(hit); // コンソールに表示

        // rayとfireが当たっていたら
        if (hit.collider.gameObject.name == "fire")
        {
            canHold = true;
            //Debug.Log("もてるよ！");
        }
        else
        {
            canHold = false;
            //Debug.Log("もてないよ！");
        }
    }
}
