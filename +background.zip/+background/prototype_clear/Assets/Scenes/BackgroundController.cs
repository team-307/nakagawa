﻿using System.Collections;
using UnityEngine;

//キャラクターが動かない場合使える
public class BackgroundController : MonoBehaviour
{
    public float scrollSpeed = -0.05f;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    void Update()
    {
        if (Input.GetKey(KeyCode.D)){
            transform.Translate(scrollSpeed, 0, 0);
         
            if (transform.position.x < -13.8f){
                transform.position = new Vector3(13.8f, 0, 0);
            }
        }
    }
}
