﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    // リジッドボディを使うための宣言
    Rigidbody2D rbody;

    // LifeCount呼び出し
    [SerializeField] private LifeCount LifeCount;

    // 変数宣言
    public int p_life;                    // ライフ

    public float speed = 5f;              // 移動する速度
    public float jumpP = 1000f;           // ジャンプ力

    public float RayLength = 1f;          // rayの長さ
    
    public bool canHold;                  // オブジェクトを持てるかどうかをfireスクリプトに渡す

    private float time;                   // delay処理

    public bool isDamaged = false;        // ダメージフラグ

    private SpriteRenderer pRenderer;     // プレイヤーのレンダラー取得

    public CameraShake shake;             // カメラ振動

    void Start()
    {
        // リジッドボディ2Dをコンポーネントから取得して変数に入れる
        rbody = GetComponent<Rigidbody2D>();

        // 体力ゲージに反映
        LifeCount.SetLifeCount(p_life);

        canHold = false;

        time = 1.0f;

        pRenderer = gameObject.GetComponent<SpriteRenderer>();
    }

    void Update()
    {
        Vector2 origin = this.transform.position; // 原点
        Vector2 direction = new Vector2(1, 0); // X軸方向を表すベクトル
        origin.x = origin.x + 1.5f;
        Ray2D ray = new Ray2D(origin, direction); // Rayを生成

        time += Time.deltaTime;


        // ジャンプ
        if (time >= 1.0f) // 1秒以内の連打をスルー
        {
            // キーボード
            // もしスペースキーが押されて、上方向に速度がない時に
            if (Input.GetKeyDown(KeyCode.Space) && rbody.velocity.y == 0)
            {
                // リジッドボディに力を加える（上方向にジャンプ力をかける）
                rbody.AddForce(transform.up * jumpP);

                time = 0.0f; // 時間を初期化
            }

            // コントローラー
            if (Input.GetButtonDown("Button_A") && rbody.velocity.y == 0)
            {
                // リジッドボディに力を加える（上方向にジャンプ力をかける）
                rbody.AddForce(transform.up * jumpP);

                time = 0.0f; // 時間を初期化
            }
        }

        // 移動(キーボード)
        if (Input.GetKey(KeyCode.A)) rbody.velocity = new Vector2(-speed, rbody.velocity.y);
        if (Input.GetKey(KeyCode.D)) rbody.velocity = new Vector2(speed, rbody.velocity.y);
        

        // 移動(コントローラー)
        const float SPEED = 0.1f;

        float x = Input.GetAxis("Horizontal_L_Stick");
        float y = Input.GetAxis("Vertical_L_Stick");

        this.gameObject.transform.position += new Vector3(x * SPEED, 0, y *0);


        // rayを表示
        Debug.DrawRay(ray.origin, ray.direction * 3, Color.red);

        // rayとオブジェクトの当たり判定
        RaycastHit2D hit = Physics2D.Raycast((Vector2)ray.origin, (Vector2)ray.direction);
        // h_name = hit.collider.name; // 衝突した相手オブジェクトの名前を取得
        //Debug.Log(hit); // コンソールに表示

        // rayとfireが当たっていたら
        if (hit.collider.gameObject.name == "fire")
        {
            canHold = true;
            //Debug.Log("もてるよ！");
        }
        else
        {
            canHold = false;
            //Debug.Log("もてないよ！");
        }


        // 点滅
        if (isDamaged) Blink();
    }

    public void Damage(int damage)
    {
        p_life -= damage;

        // ０より下の数値にならないようにする
        p_life = Mathf.Max(0, p_life);

        if (p_life >= 0)
        {
            LifeCount.SetLifeCount(p_life);
        }

        isDamaged = true;

        StartCoroutine("Wait");
    }

    // プレイヤー点滅
    public void Blink()
    {
        float level = Mathf.Abs(Mathf.Sin(Time.time * 10));
        pRenderer.color = new Color(1f, 1f, 1f, level); // 透明にする
    }

    IEnumerator Wait()
    {
        // 1秒間処理を止める
        yield return new WaitForSeconds(1);

        // １秒後ダメージフラグをfalseにする
        isDamaged = false;
        pRenderer.color = new Color(1f, 1f, 1f, 1f); // 元の色にもどす
    }

    // 敵(tyrannosaurus)と当たった時の処理
    public void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.name == "Tyrannosaurus")
        {
            //Debug.Log(p_life);
            Damage(1);
            
            //カメラ振動
            if (collision.gameObject.name == "Tyrannosaurus")
            {
                shake.Shake(0.25f, 0.1f);
            }

            if (p_life <= 0)
            {
                //Destroy(this.gameObject);
            }
        }
    }

}
