﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Example : MonoBehaviour
{
    public CameraShake shake;

    private SpriteRenderer pRenderer;     // プレイヤーのレンダラー取得

    void Start()
    {
        pRenderer = gameObject.GetComponent<SpriteRenderer>();
    }
    // 敵(tyrannosaurus)と当たった時の処理
    public void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.name == "Tyrannosaurus")
        {            
            shake.Shake(0.25f, 0.1f);
        }
    }
}
